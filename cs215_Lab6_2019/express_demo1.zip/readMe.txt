

to run server : 
open the terminal, cd to this directory,
at the prompt type: node server.js 
the server is now running.
now open firefox and enter the url: localhost:8080

to stop the server, just enter ctrl+C



